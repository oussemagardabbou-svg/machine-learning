# Customer Churn Classification

Ce projet identifie les clients susceptibles de quitter un service. Les données sont synthétiques afin que le dépôt soit autonome et reproductible.

## Approche

Une forêt aléatoire est entraînée avec une pondération `balanced` pour tenir compte du déséquilibre entre clients fidèles et clients en churn. Le rapport de classification, le ROC-AUC, la matrice de confusion et l’importance des variables sont produits automatiquement.

## Lancer le projet

```bash
pip install -r requirements.txt
cd 02_customer_churn_classification
python main.py
```

## Points à améliorer

Remplacer les données synthétiques par un fichier client réel anonymisé, calibrer les probabilités et définir un seuil de décision selon le coût d’une campagne de rétention.
