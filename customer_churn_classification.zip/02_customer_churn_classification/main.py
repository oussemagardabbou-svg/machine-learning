"""Prédiction du churn client avec données synthétiques reproductibles."""
from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.datasets import make_classification
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
from sklearn.model_selection import train_test_split

OUTPUTS = Path(__file__).resolve().parent / "outputs"
OUTPUTS.mkdir(exist_ok=True)


def main():
    X, y = make_classification(
        n_samples=2500, n_features=10, n_informative=6, n_redundant=2,
        weights=[0.72, 0.28], class_sep=1.1, random_state=42
    )
    columns = [f"feature_{i}" for i in range(X.shape[1])]
    data = pd.DataFrame(X, columns=columns)
    data["churn"] = y
    X_train, X_test, y_train, y_test = train_test_split(
        data[columns], y, test_size=0.25, stratify=y, random_state=42
    )

    model = RandomForestClassifier(
        n_estimators=250, class_weight="balanced", random_state=42, n_jobs=-1
    )
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    probabilities = model.predict_proba(X_test)[:, 1]

    print(classification_report(y_test, predictions, target_names=["Fidèle", "Churn"]))
    print(f"ROC-AUC: {roc_auc_score(y_test, probabilities):.4f}")

    matrix = confusion_matrix(y_test, predictions)
    sns.heatmap(matrix, annot=True, fmt="d", cmap="Blues", cbar=False)
    plt.title("Matrice de confusion")
    plt.xlabel("Prédiction")
    plt.ylabel("Valeur réelle")
    plt.tight_layout()
    plt.savefig(OUTPUTS / "confusion_matrix.png", dpi=150)

    importance = pd.Series(model.feature_importances_, index=columns).sort_values()
    importance.plot(kind="barh", title="Importance des variables")
    plt.tight_layout()
    plt.savefig(OUTPUTS / "feature_importance.png", dpi=150)


if __name__ == "__main__":
    main()
