# House Price Regression

Ce projet prédit la valeur médiane des logements en Californie à partir de variables géographiques et démographiques.

## Approche

Le dataset California Housing est chargé depuis scikit-learn. Les variables sont standardisées dans un pipeline puis utilisées par une régression Ridge. L’évaluation repose sur la MAE, la RMSE et le coefficient R².

## Lancer le projet

Depuis la racine du dépôt :

```bash
pip install -r requirements.txt
cd 01_house_price_regression
python main.py
```

Les prédictions et le graphique sont enregistrés dans `outputs/`.

## Points à améliorer

Tester d’autres modèles comme Random Forest ou Gradient Boosting, effectuer une validation croisée et déployer le modèle avec une API FastAPI.
