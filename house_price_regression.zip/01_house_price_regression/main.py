"""Prédiction de prix immobiliers avec un pipeline de régression."""
from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.datasets import fetch_california_housing
from sklearn.compose import TransformedTargetRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

OUTPUTS = Path(__file__).resolve().parent / "outputs"
OUTPUTS.mkdir(exist_ok=True)


def main():
    housing = fetch_california_housing(as_frame=True)
    X, y = housing.data, housing.target
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    model = Pipeline([
        ("scaler", StandardScaler()),
        ("regressor", TransformedTargetRegressor(
            regressor=Ridge(alpha=1.0), func=None, inverse_func=None
        )),
    ])
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    metrics = {
        "MAE": mean_absolute_error(y_test, predictions),
        "RMSE": mean_squared_error(y_test, predictions) ** 0.5,
        "R2": r2_score(y_test, predictions),
    }
    print("Résultats :")
    for name, value in metrics.items():
        print(f"{name}: {value:.4f}")

    results = pd.DataFrame({"actual": y_test, "predicted": predictions})
    sns.scatterplot(data=results, x="actual", y="predicted", alpha=0.35)
    plt.title("Prix réels vs prix prédits")
    plt.xlabel("Prix réel (centaines de milliers $)")
    plt.ylabel("Prix prédit")
    plt.tight_layout()
    plt.savefig(OUTPUTS / "actual_vs_predicted.png", dpi=150)
    results.to_csv(OUTPUTS / "predictions.csv", index=False)


if __name__ == "__main__":
    main()
