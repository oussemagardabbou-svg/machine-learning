# French Sentiment Analysis

Ce projet classe des avis clients en deux catégories : positif ou négatif.

## Approche

Les textes sont vectorisés avec TF-IDF, incluant des unigrammes et bigrammes, puis classés par régression logistique. Le dataset est volontairement petit et synthétique pour permettre une exécution immédiate sans téléchargement externe.

## Lancer le projet

```bash
pip install -r requirements.txt
cd 03_sentiment_analysis
python main.py
```

Le script affiche l’accuracy, le rapport de classification, deux prédictions d’exemple et sauvegarde une matrice de confusion dans `outputs/`.

## Points à améliorer

Utiliser un corpus plus large et annoté, comparer avec CamemBERT et ajouter une API de prédiction pour traiter des avis en temps réel.
