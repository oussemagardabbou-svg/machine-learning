"""Classification de sentiments avec TF-IDF et régression logistique."""
from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

OUTPUTS = Path(__file__).resolve().parent / "outputs"
OUTPUTS.mkdir(exist_ok=True)

REVIEWS = [
    ("Le produit est excellent et la livraison très rapide", 1),
    ("Je suis satisfait de la qualité et du service", 1),
    ("Une expérience agréable, je recommande vivement", 1),
    ("Très bon rapport qualité prix", 1),
    ("Le support a répondu rapidement à ma demande", 1),
    ("La qualité est remarquable et l'installation facile", 1),
    ("Je suis déçu, le produit ne fonctionne pas", 0),
    ("Livraison en retard et emballage complètement abîmé", 0),
    ("Le service client est lent et inefficace", 0),
    ("Mauvaise qualité, je ne recommande pas cet achat", 0),
    ("Le produit est inutilisable après quelques jours", 0),
    ("Très mauvais rapport qualité prix", 0),
] * 20


def main():
    data = pd.DataFrame(REVIEWS, columns=["review", "sentiment"])
    X_train, X_test, y_train, y_test = train_test_split(
        data.review, data.sentiment, test_size=0.25, stratify=data.sentiment,
        random_state=42
    )
    model = Pipeline([
        ("tfidf", TfidfVectorizer(lowercase=True, ngram_range=(1, 2))),
        ("classifier", LogisticRegression(max_iter=1000, random_state=42)),
    ])
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    print(f"Accuracy: {accuracy_score(y_test, predictions):.4f}")
    print(classification_report(y_test, predictions, target_names=["Négatif", "Positif"]))

    matrix = confusion_matrix(y_test, predictions)
    sns.heatmap(matrix, annot=True, fmt="d", cmap="Purples", cbar=False,
                xticklabels=["Négatif", "Positif"], yticklabels=["Négatif", "Positif"])
    plt.title("Matrice de confusion - Sentiment")
    plt.xlabel("Prédiction")
    plt.ylabel("Valeur réelle")
    plt.tight_layout()
    plt.savefig(OUTPUTS / "confusion_matrix.png", dpi=150)

    examples = ["Le produit est excellent et la livraison très rapide", "Mauvaise qualité, je ne recommande pas cet achat"]
    print("Exemples :")
    for text, sentiment in zip(examples, model.predict(examples)):
        print(f"- {text} -> {'positif' if sentiment else 'négatif'}")


if __name__ == "__main__":
    main()
